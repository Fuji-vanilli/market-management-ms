package mg.marketmanagement.linecommandservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LineCommandServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
