package mg.marketmanagement.entrepriseservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntrepriseServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
