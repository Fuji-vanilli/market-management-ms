package mg.marketmanagement.entrepriseservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntrepriseServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntrepriseServiceApplication.class, args);
	}

}
