package mg.marketmanagement.venteservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VenteServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
