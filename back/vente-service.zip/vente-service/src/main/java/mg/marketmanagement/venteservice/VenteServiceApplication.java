package mg.marketmanagement.venteservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VenteServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VenteServiceApplication.class, args);
	}

}
