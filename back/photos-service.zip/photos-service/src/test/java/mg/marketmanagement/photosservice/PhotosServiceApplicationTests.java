package mg.marketmanagement.photosservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotosServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
