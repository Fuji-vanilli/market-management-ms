package mg.marketmanagement.commandeclientservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommandeClientServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommandeClientServiceApplication.class, args);
	}

}
