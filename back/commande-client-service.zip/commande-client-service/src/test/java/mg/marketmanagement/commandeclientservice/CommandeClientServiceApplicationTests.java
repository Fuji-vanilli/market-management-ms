package mg.marketmanagement.commandeclientservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommandeClientServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
