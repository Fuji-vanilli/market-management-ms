package mg.marketmanagement.mouvementstockservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MouvementStockServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MouvementStockServiceApplication.class, args);
	}

}
