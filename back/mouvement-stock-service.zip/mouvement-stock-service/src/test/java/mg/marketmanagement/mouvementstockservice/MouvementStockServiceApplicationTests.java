package mg.marketmanagement.mouvementstockservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MouvementStockServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
